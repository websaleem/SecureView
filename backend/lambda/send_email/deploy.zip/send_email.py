import json
import boto3
import os

ses_client = boto3.client('ses', region_name=os.environ.get('AWS_REGION', 'ap-southeast-2'))
cognito_client = boto3.client('cognito-idp', region_name=os.environ.get('AWS_REGION', 'ap-southeast-2'))

def lambda_handler(event, context):
    try:
        body = json.loads(event.get('body', '{}'))
        access_token = body.get('accessToken')
        
        if not access_token:
            return {'statusCode': 401, 'body': json.dumps({'message': 'Missing accessToken'})}
            
        # Verify user via Cognito
        user_response = cognito_client.get_user(AccessToken=access_token)
        email = next((attr['Value'] for attr in user_response['UserAttributes'] if attr['Name'] == 'email'), None)
        name = next((attr['Value'] for attr in user_response['UserAttributes'] if attr['Name'] == 'name'), 'User')

        days = body.get('days', [])
        
        if not email:
            return {'statusCode': 400, 'body': json.dumps({'message': 'User has no email'})}

        # Compute totals
        total_seconds_all = sum(d.get('totalSeconds', 0) for d in days)
        total_hours = total_seconds_all / 3600

        # Create basic HTML report
        html_content = f"""
        <html>
        <head>
          <style>
            body {{ font-family: -apple-system, sans-serif; color: #333; }}
            .container {{ max-width: 600px; margin: 0 auto; padding: 20px; }}
            .header {{ text-align: center; border-bottom: 2px solid #2563eb; padding-bottom: 10px; margin-bottom: 20px; }}
            .stats {{ margin-bottom: 30px; }}
            .day-card {{ background: #f8fafc; border: 1px solid #e2e8f0; padding: 15px; margin-bottom: 10px; border-radius: 8px; }}
            .graph-bar {{ display: flex; height: 30px; border-radius: 4px; overflow: hidden; margin-top: 10px; }}
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h2>SecureView Weekly Report for {name}</h2>
              <p>Total Browsing Time: <strong>{total_hours:.1f} hours</strong></p>
            </div>
            <div class="stats">
              <h3>Last 7 Days Breakdown</h3>
        """

        for day in days:
            date_str = day.get('label', 'Unknown Date')
            day_total = day.get('totalSeconds', 0)
            
            # Categories
            cats = day.get('categories', {})
            
            # Simple horizontal bar graph in HTML
            graph_html = ""
            for cat_name, cat_data in cats.items():
                if day_total > 0:
                    pct = (cat_data.get('time', 0) / day_total) * 100
                    color = cat_data.get('color', '#ccc')
                    if pct > 0:
                        graph_html += f'<div style="width: {pct}%; background-color: {color};" title="{cat_name}"></div>'

            html_content += f"""
              <div class="day-card">
                <div style="display: flex; justify-content: space-between;">
                  <strong>{date_str}</strong>
                  <span>{day_total // 3600}h {(day_total % 3600) // 60}m</span>
                </div>
                <div class="graph-bar">
                  {graph_html}
                </div>
              </div>
            """

        html_content += """
            </div>
          </div>
        </body>
        </html>
        """

        ses_client.send_email(
            Source=email, # To send TO the user in the sandbox, we usually must also SEND FROM a verified email. If the user verified their email, we can use their email as both Source and Destination.
            Destination={'ToAddresses': [email]},
            Message={
                'Subject': {'Data': 'Your SecureView Browsing Report'},
                'Body': {'Html': {'Data': html_content}}
            }
        )

        return {
            'statusCode': 200,
            'headers': {'Access-Control-Allow-Origin': '*'},
            'body': json.dumps({'message': 'Email sent successfully'})
        }
    except Exception as e:
        print(e)
        return {
            'statusCode': 500,
            'headers': {'Access-Control-Allow-Origin': '*'},
            'body': json.dumps({'message': str(e)})
        }
